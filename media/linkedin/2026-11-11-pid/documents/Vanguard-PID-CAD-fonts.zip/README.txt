Vanguard FAT Studio - Polices CAO

Installer ces polices dans la CAO destinataire pour conserver les métriques du PDF.
Les DWG/DXF contiennent du texte éditable et référencent ces fichiers ; ils ne les incorporent pas.
Geist est fourni sous licence SIL Open Font License 1.1, jointe dans OFL.txt.
